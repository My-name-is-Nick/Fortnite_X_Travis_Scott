library(data.table)
library(ggplot2)
library(tidyverse)
library(forcats)

# read final data
dt <- fread('../../gen/analysis/temp/preclean.csv')

# Inladen verschillende datasets 
Voor <- fread("../../gen/data-preparation/output/dataset_before.csv") %>% as_tibble() %>% 
  # met mutate voeg je een kolom toe, waarde voor kolom moment = voor 
    mutate(moment = "Before")

During <- fread("../../gen/data-preparation/output/dataset_during.csv") %>% as_tibble() %>% 
  mutate(moment = "During")

Na <- fread("../../gen/data-preparation/output/dataset_after.csv") %>% as_tibble() %>% 
    mutate(moment = "After")


# Binding
Dataset <- Voor %>% 
  bind_rows(During) %>% 
  bind_rows(Na) %>% 
    mutate(Eigen_polarity = case_when(
    polarity > 0 ~   "Positive",
    polarity < 0 ~  "Negative",
    TRUE ~ "Neutral"
  ))


g <- Dataset %>% 
  # hier relevelen wij variabel moment,
  # dit kunnen wij pas doen op het moment dat het een factor is 
  # str(Dataset$mutate) # factor
  # fct_relevel = factor_relevel
  mutate(moment = moment %>% as_factor(),
         moment = moment %>% fct_relevel("Before", "During", "After")) %>% 
  
  # Neutraal weghalen 
  filter(Eigen_polarity != "Neutraal") %>% 
  # ggplot is de functie om de plot te maken
  # x = polarity, geen y variabele want dat doet geom_histogram zelf (tellen)
  ggplot(aes(x = polarity, fill = moment)) +
  # aantal bins = 5, je kan dit naar eigen keuze aanpassen. Default = 30
  geom_histogram(bins = 5) +
  # scales = free zorgt ervoor dat je de x-as en y-as 
  facet_wrap(Eigen_polarity ~ moment, scales = "free")


g

#install.packages("scales")


Dataset %>% 
  # Over here we relevel the variable 'moment',
  # this becomes possible when we made 'moment' into a factor
  # str(Dataset$mutate) # factor
  # fct_relevel = factor_relevel
  mutate(moment = moment %>% as_factor(),
         moment = moment %>% fct_relevel("Before", "During", "After")) %>% 
  
  # Remove Neutral plot 
  filter(Eigen_polarity != "Neutral") %>% 
  # ggplot is the functie to make a plot
  # x = polarity, no y variables because geom_histogram does this itself (counts rows)
  ggplot(aes(x = polarity, fill = moment)) +
  # number of bins = 5, eventually adjust. Default = 30
  geom_histogram(bins = 10) +
  # scales = free makes sure the x-as en y-as are scaled freely 
  # free_x scales all y-as equal
  facet_wrap(Eigen_polarity ~ moment, scales = "free_x")
#facet_wrap(Eigen_polarity ~ moment, scales = "free")

## Tabladen {.tabset .tabset-fade}


# Data manipulatie -> dplyr = %>% pipe operator 
## ggplot + 