import json

f = open('../../gen/data-preparation/temp/tweets_about_live_concert_in_videogame.json','r', encoding='utf-8')

con = f.readlines()

outfile = open('../../gen/data-preparation/temp/parsed-data.csv', 'w', encoding = 'utf-8')

outfile.write('tweet_count\tcreated_at\ttext\n')

cnt = 0
for line in con:
    if (len(line)<=5): continue

    cnt+=1
    obj = json.loads(line.replace('\n',''))

    text = obj.get('text')
    text = text.replace('\t', '').replace('\n', '')

    outfile.write(str(cnt)+'\t'+obj.get('created_at')+'\t'+text+'\n')
    if (cnt>2000): break

print('done.')
