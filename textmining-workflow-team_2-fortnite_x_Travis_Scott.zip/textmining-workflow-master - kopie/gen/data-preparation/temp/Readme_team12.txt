==========================================================
  D A T A S E T / D A T A B A S E  D E S C R I P T I O N
==========================================================

(template based on https://arxiv.org/abs/1803.09010)


* Name of the dataset/database: tweets_about_live_concert_in_videogame




==========================================================
1. MOTIVATION
==========================================================

1.1  For what purpose was the dataset created?
     Was there a specific task in mind? Was there
         a specific gap that needed to be filled?
     Please provide a description.
  \
  For the course Research in Social Media collected a dataset scraping of
  data took place 10 minutes before, during and 10 minutes after the event occurred. The data had to be suitable to use in an academic research project. The specific task for which the dataset was created was to investigate the influence of celebrity endorsement on consumer engagement in online live streams.

1.2  Who created this dataset
     (e.g., which team, research group) and on behalf of
         which entity (e.g., company, institution, organization)?
\
Group 12 of the course Research in Social Media collected the dataset on behalf of the teachers of the course Research in Social Media given at Tilburg University.

1.3  Who funded the creation of the dataset?
     If there is an associated grant, please provide
         the name of the grantor and the grant name and number.
\
There was no funding for the creation of the dataset.

1.4  Any other comments?

==========================================================
2. COMPOSITION
==========================================================

2.1  What do the instances that comprise the dataset represent
     (e.g., documents, photos, people, countries)?
     Are there multiple types of instances (e.g., movies,
         users, and ratings; people and interactions between them;
         nodes and edges)?
     Please provide a description.
\
The dataset consists of tweets. There are multiple types of instances (e.g., textual tweets, tweets containing pictures, retweets and tweets containing video recordings).

2.2  How many instances are there in total
     (of each type, if appropriate)?
\
There are 1135 instances in total.

2.3  Does the dataset contain all possible instances or is it a sample
     (not necessarily random) of instances from a larger set?
     If the dataset is a sample, then what is the larger set?
     Is the sample representative of the larger set
         (e.g., geographic coverage)? If so, please describe how this
         representativeness was validated/verified.
     If it is not representative of the larger set, please describe why not
     (e.g., to cover a more diverse range of instances, because
     instances were withheld or unavailable).
\
The dataset contains all possible instances regarding this event since tweets were scraped during the whole event with the margin of 10 minutes before and after to make sure all instances were captured.

2.4  What data does each instance consist of?
     "Raw" data (e.g., unprocessed text or images)
     or features? In either case, please provide a description.
\
Each instance consists of raw data of one tweet.

2.5  Is there a label or target associated with each instance?
     If so, please provide a description.
\
No labels were assigned to the instances yet.

2.6  Is any information missing from individual instances?
     If so, please provide a description, explaining why this information is
     missing (e.g., because it was unavailable). This does not include
         intentionally removed information, but might include, e.g., redacted text.
\
Geo location is missing for some instances. This information was unavailable because the specific user did not share their location.

2.7  Are relationships between individual instances made
     explicit (e.g., users' movie ratings, social network links)?
     If so, please describe how these relationships are made explicit.
\
People can save an instance as favorite, they can reply on an instance, they can retweet an instance, and they can quote an instance. The number of times this is done is counted and is listed in the data.

2.8  Are there recommended data splits (e.g., training, development/validation,
     testing)?
     If so, please provide a description of these splits, explaining the
     rationale behind them.
\
There are no recommended data splits.

2.9  Are there any errors, sources of noise, or redundancies in the dataset?
     If so, please provide a description.
\
The event was called Astronomical. Therefore, one of the hashtags of which tweets were scraped was #astronomical. There is a possibility that #astronomical tweets are included which do not cover the event, but astronomy.

2.10 Is the dataset self-contained, or does it link to or otherwise rely on
     external resources (e.g., websites, tweets, other datasets)?
     If it links to or relies on external resources,
     a) are there guarantees that they will exist, and remain constant,
         over time;
     b) are there official archival versions of the complete dataset
     (i.e., including the external resources as they existed at the
     time the dataset was created);
     c) are there any restrictions (e.g., licenses, fees) associated with
     any of the external resources that might apply to a future user?
     Please provide descriptions of all external resources and any restrictions
     associated with them, as well as links or other access points, as
         appropriate.
\
The dataset is self-contained as this dataset contains raw data and is not further augmented yet. Therefore, it will pertain to exist. This is the first version of the dataset. There are no restrictions that might apply to a future user.

2.11 Does the dataset contain data that might be considered confidential
     (e.g., data that is protected by legal privilege or by doctor-patient
     confidentiality, data that includes the content of individuals'
     non-public communications)?
     If so, please provide a description.
\
The dataset does not contain data that might be considered confidential since the data contains information that is placed on a public platform
by the user itself.

2.12 Does the dataset contain data that, if viewed directly, might be offensive,
     insulting, threatening, or might otherwise cause anxiety?
     If so, please describe why.
\
Some tweets might contain moderately inappropriate or offensive language, this is not expected to be the norm.

2.13 Does the dataset relate to people?
     If not, you may skip the remaining questions in this section.
\
Yes, the dataset relates to people as all instances are created by people. However, the dataset only contains usernames and not actual full names.

2.14 Does the dataset identify any subpopulations (e.g., by age, gender)?
     If so, please describe how these subpopulations are identified and
     provide a description of their respective distributions within the dataset.
\
No the dataset does not identify any subpopulations. Location possibly can be used as a subpopulation, however not all users shared their location.

2.15 Is it possible to identify individuals (i.e., one or more natural persons),
     either directly or indirectly (i.e., in combination with other data)
     from the dataset?
     If so, please describe how.
\
It might be possible to identify individuals indirectly in combination with other data, based on their usernames. However this data is not available for team 12.

2.16 Does the dataset contain data that might be considered sensitive in
     any way (e.g., data that reveals racial or ethnic origins, sexual
     orientations, religious beliefs, political opinions or union memberships,
     or locations; financial or health data; biometric or genetic data;
     forms of government identification, such as social security numbers;
     criminal history)?
     If so, please provide a description.
\
It is possible that the dataset contains this kind of information. If users choose to incorporate this kind of sensitive data in their tweets and/or usernames. However, since this kind of information does not relate to the event, this is not expected to be the case.

2.17 Any other comments?

==========================================================
3. COLLECTION PROCESS
==========================================================

3.1  How was the data associated with each instance acquired?
     Was the data directly observable (e.g., raw text, movie ratings),
     reported by subjects (e.g., survey responses), or indirectly
         inferred/derived from other data (e.g., part-of-speech tags, model-based
        guesses for age or language)? If data was reported by subjects or indirectly
     inferred/derived from other data, was the data validated/verified?
     If so, please describe how.
\
The data was directly observable as the tweets consist of raw text.

3.2  What mechanisms or procedures were used to collect the data
     (e.g., hardware apparatus or sensor, manual human curation,
         software program, software API)?
     How were these mechanisms or procedures validated?
\
First a developer account had to be created on Twitter to get access to API keys and tokens. Then tweepy_student.ipynb was downloaded to get the code in Jupyter Notebook 6.0.3. Tweets were scraped with the twitter API for the hashtags #fortnite, #travisscott, #fortniteconcert and #astronomical. The tweets were scraped simultaneously by two people on different devices. Scraping was monitored continuously to ensure everything was running correctly. Afterwards, the data was inspected visually to ensure no gaps were present in the dataset.

3.3  If the dataset is a sample from a larger set, what was the sampling strategy
     (e.g., deterministic, probabilistic with specific sampling probabilities)?
\
The dataset is not a sample.

3.4  Who was involved in the data collection process (e.g., students,
       crowdworkers, contractors) and how were they compensated (e.g., how
         much were crowdworkers paid)?
\
Two members (students) of Team 12 were involved in the data collection process. Because the data collection is done for educational purposes, no one is compensated.


3.5  Over what timeframe was the data collected? Does this timeframe
     match the creation timeframe of the data associated with the
     instances (e.g., recent crawl of old news articles)?
     If not, please describe the timeframe in which the data associated with the
     instances was created.
\
The data was collected on Saturday, April 25 2020 from 16:50 until 17:25. This timeframe matches the creation of the data associated with the instances as this was the time of the event for which the data has been scraped.

3.6  Were any ethical review processes conducted (e.g., by an institutional
     review board)?
     If so, please provide a description of these review processes, including
     the outcomes, as well as a link or other access point to any
     supporting documentation.
\
No ethical review processes were conducted.

3.7  Does the dataset relate to people?
     If not, you may skip the remainder of the questions in this section.
\
Yes, each instance is a tweet of a person. There might be some tweets send by a person in name of a company/organization.

3.8  Did you collect the data from the individuals in question directly,
     or obtain it via third parties or other sources (e.g., websites)?
\
The data was obtained via a third party, namely the Twitter website.

3.9  Were the individuals in question notified about the data collection?
     If so, please describe(or show with screenshots or other information) how
     notice was provided, and provide a link or other access point to,
     or otherwise reproduce, the exact language of the notification itself.
\
No, individuals were not notified about the data collection. But they know that their tweet and other data are immediately viewable and searchable by anyone since Twitter is a public platform.

3.10 Did the individuals in question consent to the collection and use of their
     data?
     If so, please describe (or show with screenshots or other information)
     how consent was requested and provided, and provide a link or other access
     point to, or otherwise reproduce, the exact language to which the
     individuals consented.
\
Yes, individuals consent to the collection and use of their data via accepting the Privacy Policy of Twitter. For more information see https://twitter.com/en/privacy.

3.11 If consent was obtained, were the consenting individuals provided with a
     mechanism to revoke their consent in the future or for certain uses?
     If so, please provide a description, as well as a link or other access
     point to the mechanism (if appropriate).
\
Those individuals are in control through their own settings in limiting the data Twitter collect from them and how they use it. For more information see https://twitter.com/en/privacy.

3.12 Has an analysis of the potential impact of the dataset and its use on data
     subjects (e.g., a data protection impact analysis)been conducted?
     If so, please provide a description of this analysis, including the
         outcomes, as well as a link or other access point to any supporting
         documentation.
\
No analysis has been conducted yet.

3.13 Any other comments?

==========================================================
4. PREPROCESSING/CLEANING/LABELING
==========================================================

4.1  Was any preprocessing/cleaning/labeling of the data done (e.g.,
       discretization or bucketing, tokenization, part-of-speech tagging,
         SIFT feature extraction, removal of instances, processing of
         missing values)? If so, please provide a description. If not, you may skip
         the remainder of the questions in this section.

4.2  Was the "raw" data saved in addition to the
     preprocessed/cleaned/labeled data (e.g., to support unanticipated
         future uses)? If so, please provide a link or other access point to
         the "raw" data.

4.3  Is the software used to preprocess/clean/label the instances available?
     If so, please provide a link or other access point.

4.4  Any other comments?


==========================================================
5. USES
==========================================================

5.1  Has the dataset been used for any tasks already?
     If so, please provide a description.
\
No, the dataset has not been used for any tasks already.

5.2  Is there a repository that links to any or all papers or systems
     that use the dataset?
     If so, please provide a link or other access point.
\
No there is no repository yet.

5.3  What (other) tasks could the dataset be used for?
\
Of course there are other research questions which can be analyzed with this dataset. For example to analyze the engagement pattern (e.g., volume, retweets) for an live concert in a videogame. Another example could be to analyze how multiscreening (e.g., gaming and tweeting at the same time) affects brand efficiency of Fortnite.

5.4  Is there anything about the composition of the dataset or the way it was
         collected and preprocessed/cleaned/labeled that might impact future uses?
         For example, is there anything that a future user might need to know to
         avoid uses that could result in unfair treatment of individuals or groups
         (e.g., stereotyping, quality of service issues) or other undesirable harms
         (e.g., financial harms, legal risks) If so, please provide a description.
         Is there anything a future user could do to mitigate these undesirable
         harms?
\
As the data has not been cleaned yet, there is nothing about the     composition of the dataset that might impact future uses.

5.5  Are there tasks for which the dataset should not be used?
     If so, please provide a description.
\
This dataset was scraped for educational purposes for the course Research in Social Media at Tilburg University. Permission was granted by Twitter for this specific purpose, therefore, this dataset should not be used for any other means than educational purposes.

5.6  Any other comments?

==========================================================
6. DISTRIBUTION
==========================================================

6.1  Will the dataset be distributed to third parties outside of the entity
     (e.g., company, institution, organization) on behalf of which the
     dataset was created?
     If so, please provide a description.

6.2  How will the dataset will be distributed(e.g.,tarball on website, API,
       GitHub)? Does the dataset have a digital object identifier (DOI)?

6.3  When will the dataset be distributed?

6.4  Will the dataset be distributed under a copyright or other intellectual
     property(IP) license, and/or under applicable terms of use (ToU)?
     If so, please describe this license and/or ToU, and provide a link or other
     access point to, or otherwise reproduce, any relevant licensing terms or
         ToU (Terms of Use), as well as any fees associated with these restrictions.

6.5  Have any third parties imposed IP-based or other restrictions on the
     data associated with the instances?
     If so, please describe these restrictions, and provide a link or other
     access point to, or otherwise reproduce, any relevant licensing terms,
     as well as any fees associated with these restrictions.

6.6  Do any export controls or other regulatory restrictions apply to the
     dataset or to individual instances?
     If so, please describe these restrictions, and provide a link or other
     access point to, or otherwise reproduce, any supporting documentation.

6.7  Any other comments?

==========================================================
7. MAINTENANCE
==========================================================

7.1  Who is supporting/hosting/maintaining the dataset?

7.2  How can the owner/curator/manager of the dataset be contacted
     (e.g., email address)?

7.3  Is there an erratum?
     If so, please provide a link or other access point.

7.4  Will the dataset be updated (e.g., to correct labeling errors, add
     new instances, delete instances)?
     If so, please describe how often, by whom, and how updates will
     be communicated to users (e.g., mailing list, GitHub)?

7.5  If the dataset relates to people, are there applicable limits on the
     retention of the data associated with the instances
     (e.g., were individuals in question told that their data would be retained
       for a fixed period of time and then deleted)?
     If so, please describe these limits and explain how they will be enforced.

7.6  Will older versions of the dataset continue to be
     supported/hosted/maintained?
     If so, please describe how. If not, please describe how its obsolescence
     will be communicated to users.

7.7  If others want to extend/augment/build on/contribute to the dataset,
     is there a mechanism for them to do so?
     If so, please provide a description. Will these contributions be
     validated/verified?
     If so, please describe how. If not, why not? Is there a process for
     communicating/distributing these contributions to other users?
     If so, please provide a description.

7.8  Any other comments?
