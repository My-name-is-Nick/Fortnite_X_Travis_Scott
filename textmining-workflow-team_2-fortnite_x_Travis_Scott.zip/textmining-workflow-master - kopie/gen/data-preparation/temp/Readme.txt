==========================================================
  D A T A S E T / D A T A B A S E  D E S C R I P T I O N
==========================================================

* Name of the dataset/database:
Collection of tweets related to Donald Trump on the pronunciation
of injecting disinfectant


==========================================================
1. MOTIVATION
==========================================================

1.1  For what purpose was the dataset created?
     Was there a specific task in mind? Was there
         a specific gap that needed to be filled?
     Please provide a description.

     How does the Twitter community in America (divided in geographical clusters)
     react to Donald Trump's statement that the coronavirus must be fought by injecting
     disinfectant?

     Description: Medics fear that American citizens themselves will take up
     Trump's suggestion. Only this week, a government health service found that
     the number of poisonings caused by cleaning agents and disinfectants in
     the coronary pandemic has skyrocketed. Even though Trump said something
     that could be interpreted controversially, we want to know what the reaction
     is on State level based upon his popularity. Since this is an interesting
     recent topic, it seems worthwhile to us to collect a dataset of it.

1.2  Who created this dataset
     (e.g., which team, research group) and on behalf of
         which entity (e.g., company, institution, organization)?

      This dataset is created by team 23, from the course Research in Social Media
      from the Master Marketing Management at Tilburg University. Two of the students
      from this group activated the API web scraper to collect the Twitter data.

1.3  Who funded the creation of the dataset?
     If there is an associated grant, please provide the name of the grantor and
     the grant name and number.

     The creation of the dataset is provided by data from Twitter.

1.4  Any other comments?

==========================================================
2. COMPOSITION
==========================================================

2.1  What do the instances that comprise the dataset represent
     (e.g., documents, photos, people, countries)?
     Are there multiple types of instances (e.g., movies,
         users, and ratings; people and interactions between them;
         nodes and edges)?
     Please provide a description.

    The data in the dataset consist of tweets (From twitter.com) from specific users
    who used the #Trump. Or retweeted a tweet which contained #Trump after he gave
    his speech on 24-04-2020 about the injection of disinfectants.

2.2  How many instances are there in total
     (of each type, if appropriate)?

     There are 3.585 individual tweets collected in the process with the hashtag #Trump.
     Since this is a raw data set, there has not yet been filtered which tweets
     are appropriate and which tweets are inappropriate.

2.3  Does the dataset contain all possible instances or is it a sample
     (not necessarily random) of instances from a larger set?
     If the dataset is a sample, then what is the larger set?
     Is the sample representative of the larger set
         (e.g., geographic coverage)? If so, please describe how this
         representativeness was validated/verified.
     If it is not representative of the larger set, please describe why not
     (e.g., to cover a more diverse range of instances, because
     instances were withheld or unavailable).

     The dataset is a sample of a bigger dataset. Due to the Coronavirus President Trump
     gave a speech to let the people of the USA know how they are controlling the
     ongoing situation. We wanted to see what the overall opinion of the people is
     concerning Donald Trump at this moment. The dataset contains a sample of 10 minutes
     of tweets with the #Trump. Since we believe this dataset might not be completely
     representative due to the fact that we want to segment on States, the final analysis
     might give an indication about the opinion the several States have about the president.
     For a complete representative analysis we simply need a larger dataset.

2.4  What data does each instance consist of?
     "Raw" data (e.g., unprocessed text or images)
     or features? In either case, please provide a description.

     The data consists of Raw data. The raw data was collected in ATOM and with
     JSON viewer each object can be visualized. In JSON viewer there is an overview
     of the user, retweet status and entities of one user that used the hashtag #Trump.
     The overview of these variables contains other important variables like
     the user id, username, profile image, followers, geographical location and likes.

2.5  Is there a label or target associated with each instance?
     If so, please provide a description.

     There are no labels or target associated with each object in the dataset.
     However, all the instances have an unique user id.

2.6  Is any information missing from individual instances?
     If so, please provide a description, explaining why this information is
     missing (e.g., because it was unavailable). This does not include
     intentionally removed information, but might include, e.g., redacted text.

     Since data only will be retrieved when a tweet is available, no information
     from individual instances will be missed.

2.7  Are relationships between individual instances made
     explicit (e.g., users' movie ratings, social network links)?
     If so, please describe how these relationships are made explicit.

     There is a relationship between the individual instances, because they all
     have tweeted with the #Trump. Some tweets are also
     retweets (A message which someone can reply to). There is no social network
     link between the individual instances, because the tweets are gathered from
     all around the world.

2.8  Are there recommended data splits (e.g., training, development/validation,
     testing)?
     If so, please provide a description of these splits, explaining the
     rationale behind them.

     At this moment there are no recommended data splits.

2.9  Are there any errors, sources of noise, or redundancies in the dataset?
     If so, please provide a description.

     Since we gathered data from all over the world, there might be foreign language
     Tweets for the researchers which have to be translated into English.
     When translating the languages into English, several translation biases might occur,
     which may lead into different interpretations than the Tweet was originally intended to.

2.10 Is the dataset self-contained, or does it link to or otherwise rely on
     external resources (e.g., websites, tweets, other datasets)?
     If it links to or relies on external resources,
     a) are there guarantees that they will exist, and remain constant,
         over time;
     b) are there official archival versions of the complete dataset
     (i.e., including the external resources as they existed at the
     time the dataset was created);
     c) are there any restrictions (e.g., licenses, fees) associated with
     any of the external resources that might apply to a future user?
     Please provide descriptions of all external resources and any restrictions
     associated with them, as well as links or other access points, as
     appropriate.

     The dataset is not self-contained, but retrieved from the external
     resource: Twitter with a public API key.  There is no guarantee that Twitter
     will have this APA available for a longer time, but this specific dataset is
     stored in Google Drive so this will be available.

2.11 Does the dataset contain data that might be considered confidential
     (e.g., data that is protected by legal privilege or by doctor-patient
     confidentiality, data that includes the content of individuals'
     non-public communications)?
     If so, please provide a description.

     At this moment all the information that is gathered is public information
     from twitter. So there is no confidential data being gathered.

2.12 Does the dataset contain data that, if viewed directly, might be offensive,
     insulting, threatening, or might otherwise cause anxiety?
     If so, please describe why.

     The dataset contains Tweets that are offensive and insulting. That is
     mainly because Trump made a bold statement which causes a lot of chaos and
     resulted in tweets that have a lot of different opinions. Besides, we individually
     assessed whether the data contained strong language or not.

2.13 Does the dataset relate to people?
     If not, you may skip the remaining questions in this section.

     Yes, all the data is related to people because individuals wrote the tweets.

2.14 Does the dataset identify any subpopulations (e.g., by age, gender)?
     If so, please describe how these subpopulations are identified and
     provide a description of their respective distributions within the dataset.

     No, since the dataset has not been elaborated yet. It is possible though to
     identify subpopulations in JSON viewer.

2.15 Is it possible to identify individuals (i.e., one or more natural persons),
     either directly or indirectly (i.e., in combination with other data)
     from the dataset?
     If so, please describe how.

     It is possible to identify any individuals from the dataset, because they
     use their own username which can be linked back to their real name.
     They also have a screen name which refers to their own name.

2.16 Does the dataset contain data that might be considered sensitive in
     any way (e.g., data that reveals racial or ethnic origins, sexual
     orientations, religious beliefs, political opinions or union memberships,
     or locations; financial or health data; biometric or genetic data;
     forms of government identification, such as social security numbers;
     criminal history)?
     If so, please provide a description.

     The dataset comprises Tweets that contains strong language. That is mainly
     because Trump made a bold statement which causes a lot of chaos and resulted
     in tweets that have a lot of different political opinions.

2.17 Any other comments?

==========================================================
3. COLLECTION PROCESS
==========================================================

3.1  How was the data associated with each instance acquired?
     Was the data directly observable (e.g., raw text, movie ratings),
     reported by subjects (e.g., survey responses), or indirectly
     inferred/derived from other data (e.g., part-of-speech tags, model-based
     guesses for age or language)? If data was reported by subjects or indirectly
     inferred/derived from other data, was the data validated/verified?
     If so, please describe how.

     The data was directly observable, since the scraper generated all the data
     during the time that the scraper was online. Since the messages are user-generated,
     it is not validated or verified.

3.2  What mechanisms or procedures were used to collect the data
     (e.g., hardware apparatus or sensor, manual human curation,
         software program, software API)?
     How were these mechanisms or procedures validated?

     Twitter API Scraper is the mechanism which is used to collect the data.
     This mechanism provides unvalidated data. The data has been collected twice
     at the same time by two different accounts, which leads to a higher reliability
      and validity. There are no gaps or errors found in the data, on both accounts.

3.3  If the dataset is a sample from a larger set, what was the sampling strategy
     (e.g., deterministic, probabilistic with specific sampling probabilities)?

     The dataset is a sample generated by the simple random sampling method
     of the total population.

3.4  Who was involved in the data collection process (e.g., students,crowdworkers,
      contractors) and how were they compensated (e.g., how much were crowdworkers paid)?

      Students gathered the data without any kind of compensation, which was
      made possible by the API Twitter gave access to.

3.5  Over what timeframe was the data collected? Does this timeframe
     match the creation timeframe of the data associated with the
     instances (e.g., recent crawl of old news articles)?
     If not, please describe the timeframe in which the data associated with the
     instances was created.

     The data was collected during a timeframe of 16 minutes. We can verify this
     by looking at our text editor where we can see that the first tweet has
     created at "Fri Apr 24 15:01:18” and the last tweet at
     "Fri Apr 24 14:45:05”.


3.6  Were any ethical review processes conducted (e.g., by an institutional
     review board)?
     If so, please provide a description of these review processes, including
     the outcomes, as well as a link or other access point to any
     supporting documentation.
     There was no ethical review process conducted during the data collection.


3.7  Does the dataset relate to people?
     If not, you may skip the remainder of the questions in this section.
     Yes, this dataset relates to people, since they are the ones writing the tweets.
3.8  Did you collect the data from the individuals in question directly,
     or obtain it via third parties or other sources (e.g., websites)?

     The data is obtained via Twitter, which is a third party.

3.9  Were the individuals in question notified about the data collection?
     If so, please describe(or show with screenshots or other information) how
     notice was provided, and provide a link or other access point to,
     or otherwise reproduce, the exact language of the notification itself.

     The individuals in question were not notified about the data collection,
     but the students have permission from Twitter to scrape the data.

3.10 Did the individuals in question consent to the collection and use of their
     data?
     If so, please describe (or show with screenshots or other information)
     how consent was requested and provided, and provide a link or other access
     point to, or otherwise reproduce, the exact language to which the
     individuals consented.

     No, this was not the case, since the individuals were not aware that their
     data was being recorded by the students. In the URL provided you can read
     the Terms of Services, on which individuals agree before they get access
     to the Twitter interface: https://twitter.com/en/tos

3.11 If consent was obtained, were the consenting individuals provided with a
     mechanism to revoke their consent in the future or for certain uses?
     If so, please provide a description, as well as a link or other access
     point to the mechanism (if appropriate).

     No consent was obtained. If an individual Tweets something that the Twitter
     algorithm detects as offensive, the Tweet will be removed and the user can
     reactivate his/her account by logging in again. The information has already
     been collected and cannot be revoked.

3.12 Has an analysis of the potential impact of the dataset and its use on data
     subjects (e.g., a data protection impact analysis)been conducted?
     If so, please provide a description of this analysis, including the
         outcomes, as well as a link or other access point to any supporting
         documentation.

      This was not the case, since no analysis has been done yet.

3.13 Any other comments?

==========================================================
4. PREPROCESSING/CLEANING/LABELING
==========================================================

4.1  Was any preprocessing/cleaning/labeling of the data done (e.g.,
       discretization or bucketing, tokenization, part-of-speech tagging,
         SIFT feature extraction, removal of instances, processing of
         missing values)? If so, please provide a description. If not, you may skip
         the remainder of the questions in this section.

4.2  Was the "raw" data saved in addition to the
     preprocessed/cleaned/labeled data (e.g., to support unanticipated
         future uses)? If so, please provide a link or other access point to
         the "raw" data.

4.3  Is the software used to preprocess/clean/label the instances available?
     If so, please provide a link or other access point.

4.4  Any other comments?


==========================================================
5. USES
==========================================================

5.1  Has the dataset been used for any tasks already?
     If so, please provide a description.

No, the dataset has not been used yet.



5.2  Is there a repository that links to any or all papers or systems
     that use the dataset?
     If so, please provide a link or other access point.

     The dataset is currently being stored in Google Drive.
     URL:drive.google.com/drive/u/1/folders/1yK5vJgk8usOGzvxCsmJmn3XLk_KC4U-z


5.3  What (other) tasks could the dataset be used for?

    Based on the available data, we could analyze several things. For example:
      - The percentage of the sample that includes an opinion (positive/negative)
      about the president of the United States could be measured;
      - Measuring the percentage of respondents that agree or disagree with Trump's
      statement during the press conference;
      - What are the subjects that are currently being associated with Trump;

5.4  Is there anything about the composition of the dataset or the way it was
         collected and preprocessed/cleaned/labeled that might impact future uses?
         For example, is there anything that a future user might need to know to
         avoid uses that could result in unfair treatment of individuals or groups
         (e.g., stereotyping, quality of service issues) or other undesirable harms
         (e.g., financial harms, legal risks) If so, please provide a description.
         Is there anything a future user could do to mitigate these undesirable
         harms?
         For example, is there anything that a future user might need to know to
         avoid uses that could result in unfair treatment of individuals or groups
         (e.g., stereotyping, quality of service issues) or other undesirable harms
         (e.g., financial harms, legal risks) If so, please provide a description.
         Is there anything a future user could do to mitigate these undesirable
         harms?

         This is not the case, since the data gathering was purely purposed for
         educational purposes. The composition of the dataset has not been changed.
         This is a raw dataset.

5.5  Are there tasks for which the dataset should not be used?
     If so, please provide a description.


     The dataset is purely meant for educational analysis. Therefore, it's purpose
     is not meant as evidence for any kind of political statement or to influence
     people's opinion about the president.


5.6  Any other comments?

==========================================================
6. DISTRIBUTION
==========================================================

6.1  Will the dataset be distributed to third parties outside of the entity
     (e.g., company, institution, organization) on behalf of which the
     dataset was created?
     If so, please provide a description.

6.2  How will the dataset will be distributed(e.g.,tarball on website, API,
       GitHub)? Does the dataset have a digital object identifier (DOI)?

6.3  When will the dataset be distributed?

6.4  Will the dataset be distributed under a copyright or other intellectual
     property(IP) license, and/or under applicable terms of use (ToU)?
     If so, please describe this license and/or ToU, and provide a link or other
     access point to, or otherwise reproduce, any relevant licensing terms or
         ToU (Terms of Use), as well as any fees associated with these restrictions.

6.5  Have any third parties imposed IP-based or other restrictions on the
     data associated with the instances?
     If so, please describe these restrictions, and provide a link or other
     access point to, or otherwise reproduce, any relevant licensing terms,
     as well as any fees associated with these restrictions.

6.6  Do any export controls or other regulatory restrictions apply to the
     dataset or to individual instances?
     If so, please describe these restrictions, and provide a link or other
     access point to, or otherwise reproduce, any supporting documentation.

6.7  Any other comments?

==========================================================
7. MAINTENANCE
==========================================================

7.1  Who is supporting/hosting/maintaining the dataset?

7.2  How can the owner/curator/manager of the dataset be contacted
     (e.g., email address)?

7.3  Is there an erratum?
     If so, please provide a link or other access point.

7.4  Will the dataset be updated (e.g., to correct labeling errors, add
     new instances, delete instances)?
     If so, please describe how often, by whom, and how updates will
     be communicated to users (e.g., mailing list, GitHub)?

7.5  If the dataset relates to people, are there applicable limits on the
     retention of the data associated with the instances
     (e.g., were individuals in question told that their data would be retained
       for a fixed period of time and then deleted)?
     If so, please describe these limits and explain how they will be enforced.

7.6  Will older versions of the dataset continue to be
     supported/hosted/maintained?
     If so, please describe how. If not, please describe how its obsolescence
     will be communicated to users.

7.7  If others want to extend/augment/build on/contribute to the dataset,
     is there a mechanism for them to do so?
     If so, please provide a description. Will these contributions be
     validated/verified?
     If so, please describe how. If not, why not? Is there a process for
     communicating/distributing these contributions to other users?
     If so, please provide a description.

7.8  Any other comments?
